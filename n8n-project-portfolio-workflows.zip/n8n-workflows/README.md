# n8n Project Portfolio Workflows

These files are safe, inactive portfolio templates. They use sample records so the business logic can be demonstrated before live credentials are connected.

## Import order

1. Import `00-shared-error-handler.json` first.
2. Import projects `01` through `07` into the **Project Portfolio** folder.
3. Open each project workflow's **Workflow Settings** and select **00 - Shared Portfolio Error Handler** as its Error workflow.
4. Run **Start Portfolio Demo** and inspect each decision branch.
5. Connect credentials only after the sample paths work as expected.

You can import a file from n8n's workflow menu, or open a blank canvas and paste the complete JSON content.

## What is included

| File | Scope | Native/AI design |
|---|---|---|
| `01-automated-invoice-processing.json` | Invoice intake, extraction, duplicate/vendor/total/PO checks, review, accounting draft, audit | Native IF/Edit Fields/Merge plus AI Information Extractor and Structured Output Parser |
| `02-ai-customer-support-and-appointment-booking.json` | Chat support, RAG, appointments, sensitive-question handoff, CRM logging, optional voice channel | AI Agent, model, memory, vector search tool, embeddings, calculator tool, output parser, Vapi, ElevenLabs, Airtable |
| `03-automatic-lead-assignment-and-follow-up.json` | Duplicate check, contact permission, priority, assignment, replies, follow-up limit, CRM logging | Native IF/Edit Fields/Merge/Wait plus Airtable CRM |
| `04-automated-customer-payment-follow-up.json` | Paid/dispute/VIP checks, overdue stages, approval, reminder preparation, collection log | Native Schedule/IF/Edit Fields/Wait plus Airtable |
| `05-automatic-order-and-inventory-checking.json` | Stock check, reservation, reorder alert, alternatives, large-order approval | Native Webhook/IF/Edit Fields/Wait plus Airtable |
| `06-content-planning-and-publishing-automation.json` | Source checking, AI drafting, channel versions, brand checks, approval, publishing, metrics | AI Agent, model, vector source tool, embeddings, output parser, native approvals, Airtable |
| `07-real-estate-lead-follow-up-and-viewing-booking.json` | Property availability, qualification, alternatives, viewing slots, confirmation, CRM update | Native Webhook/IF/Edit Fields/Wait plus Airtable CRM |

## Safety and credentials

- All workflows import as inactive.
- Live triggers and credential-dependent integration nodes are disabled.
- No API keys are stored in these files.
- Airtable base IDs, Vapi assistant IDs, and ElevenLabs voice IDs are placeholders.
- AI nodes retry temporary failures up to three times and preserve normal workflow data if the external AI service fails.
- Human approval Wait nodes are disabled for instant portfolio demos. Enable them only after the approval notification and resume link are configured.
- Invoice workflows create only an accounting **draft**. They never pay or finally post an invoice.
- Content workflows never publish without human approval.

## Credentials to prepare

- OpenAI or another supported chat and embedding model
- Supabase/Pinecone/another vector store for approved knowledge
- Airtable personal access token and base/table IDs
- Gmail/Outlook or WhatsApp provider for messages
- Google Calendar or Microsoft Outlook Calendar
- QuickBooks/Xero sandbox for the invoice project
- Vapi private API key and assistant ID for the optional voice channel
- ElevenLabs API key and voice ID for the optional voice channel

## Voice-agent lane

The customer-support workflow includes an optional voice architecture:

1. Vapi call event enters through the dedicated webhook.
2. The AI Agent receives the transcript or message.
3. The agent searches approved knowledge, uses allowed tools, and returns a structured answer.
4. ElevenLabs can generate the chosen voice response.
5. Vapi manages the call interaction.
6. The transcript, answer source, appointment outcome, and handoff result are saved to Airtable.

The current Vapi create-call endpoint and ElevenLabs text-to-speech endpoint are already represented in disabled HTTP Request nodes. Add authentication through n8n Credentials rather than typing API keys into the workflow.

## Human-in-the-loop points

- Finance reviews suspicious invoices and final notices.
- Support reviews sensitive or unsupported customer questions.
- Senior salespeople accept important leads.
- Operations approves large stock commitments.
- A person approves every public content item.
- A real-estate agent confirms viewing arrangements.

## Error handling

The shared error workflow receives failed execution details, preserves the workflow name, execution ID, failed node, and error message, then separates temporary retry candidates from failures that require a person. Business-critical failures receive urgent handling. Connect its notification node to Slack or email and its Airtable node to an `Automation Error Log` table.

